"""myproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from django.urls import include
import homeapp.urls

import loginapp.urls

urlpatterns = [
    path('admin/', admin.site.urls), #http://127.0.0.1:8000/admin
    path('',include(homeapp.urls)),#http://127.0.0.1:8000/

    #http://127.0.0.1:8000/about
    # are there any mapping for 'about/' ? --> NO
    # Atleaseat are there any mapping for 'http://127.0.0.1:8000/'? YES --> homeapp.urls

    path('signup/',include(loginapp.urls)), #http://127.0.0.1:8000/signup

    #http://127.0.0.1:8000/loginapp/createnewaccount/
    # are there any mapping for "createnewaccount/" ? NO
    # are there any mapping for "loginapp/" ? NO
    # are thee any mapping for "http://127.0.0.1:8000/" ? YES --> homeapp.urls
    # We don't want to dispatch to homeapp.urls

    path("loginapp/",include(loginapp.urls)), 

    # NOW,
    # http://127.0.0.1:8000/loginapp/createnewaccount/
    # are there any mapping for "createnewaccount/" ? NO
    # are there any mapping for "loginapp/" ? YES --> loginapp.urls
    # Now, in loginapp.urls --> check for are there any mapping for "createnewaccount/"

    # path("myapi/",include(loginapp.urls)), 
        

]
