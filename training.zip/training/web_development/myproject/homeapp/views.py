from django.shortcuts import render

# Create your views here.

from django.shortcuts import HttpResponse

#def my_home_page(request):
#    return HttpResponse("Welcome")

def my_home_page(request):
    return render(request,"home.html",{}) # {}-> We dont want to send any data to .html

def my_about_page(request):
    return render(request,"about.html",{})
