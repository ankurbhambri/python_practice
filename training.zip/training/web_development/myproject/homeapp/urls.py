from . import views
from django.urls import path

urlpatterns = [
    path('',views.my_home_page),
    path('about/',views.my_about_page),
    ]
