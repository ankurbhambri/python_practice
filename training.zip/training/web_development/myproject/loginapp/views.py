from django.shortcuts import render,HttpResponse

# Create your views here.
def my_signup_page(request):
    return render(request,'signup.html',{})


def my_newaccount_page(request):
    # all data got stored in request.POST dictionary, if method is GET then data will be in request.GET dictionary
    # retreive all the data

    entered_username  = request.POST.get("myuname") # OR request.POST["Key"] OR request.POST.get("Key")
    entered_password1 = request.POST.get("mypwd1")
    entered_password2 = request.POST.get("mypwd2")
    entered_email     = request.POST.get("myemail")

    if entered_username == '' or entered_password1 == '' or entered_password2 == '' or entered_email == '':
        return HttpResponse("Fields can't be empty <a href='/signup'>Go Back</a>")
    elif entered_password1 != entered_password2:
        return HttpResponse("password1 and password2 didn't match <a href='/signup'>Go Back</a>")
    else:
        from .models import MyModel

        # Check whehter username present or not

        if MyModel.objects.filter(name=entered_username).exists() == True:
            return HttpResponse("User Already Exisits <a href='/signup'>Go Back</a>")
        else:
            new_user = MyModel()
            new_user.name=entered_username
            new_user.password=entered_password1
            new_user.email=entered_email
            new_user.save()
            return HttpResponse("Registration Sucees <a href='/'>Go HOME</a>")
            
            
    
def my_login_page(request):
    # we can write html form like signup.html
    # OR
    # we can also use django forms
    # advantages: validation and all is simple
    # Generating response during failure also taken care

    from .forms import MyForm
    f = MyForm()
    return render(request,"login.html",{"myfm":f}) 


def my_logreport_page(request):

    # Option :-1
    #entered_username  = request.POST.get("username") # OR request.POST["Key"] OR request.POST.get("Key")
    #entered_password1 = request.POST.get("password")

    # Option :-2
    from .forms import MyForm
    f = MyForm(request.POST)
    if f.is_valid():
        u = f.cleaned_data["username"]
        p = f.cleaned_data["password"]
        request.session['usernameinsession'] = u
        from .models import MyModel
        if MyModel.objects.filter(name=u).exists() == True:
            import sqlite3
            con = sqlite3.connect(r"C:\training\bin\my_database.sqlite3")
            cur = con.cursor()
            cur.execute("SELECT * FROM MY_WEBSITE_DATA")
            db_result = cur.fetchall()
            return render(request,"myreport.html",{"dbdata":db_result})
            
        else:
            return HttpResponse("User/password didnt match <a href='/login'>Go Back</a>")
        
    else:
        return HttpResponse("Please enter valid data <a href='/login'>Go Back</a>")
        
    
    

def my_logout_page(request):
    if request.session.get('usernameinsession'):
        del request.session['usernameinsession']
        return HttpResponse("Logout Success <a href='/'>Go Home</a>")
    else:
        return HttpResponse("Not Logged IN.. <a href='/'>Go Home</a>")
