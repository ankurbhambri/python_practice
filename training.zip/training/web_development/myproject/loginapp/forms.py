from django import forms

class MyForm(forms.Form):
    username = forms.CharField(max_length=50) # <input type = "text"
    password = forms.CharField(max_length=50,widget=forms.PasswordInput()) # <input type = "password"
    
