from . import views
from django.urls import path

urlpatterns = [
    path('',views.my_signup_page),
    path('createnewaccount/',views.my_newaccount_page),

    #http://127.0.0.1:8000/loginapp/login/
    path('login/',views.my_login_page),

    #http://127.0.0.1:8000/loginapp/logreport/
    path('logreport/',views.my_logreport_page),

    #http://127.0.0.1:8000/loginapp/logout/
    path("logout/",views.my_logout_page),
    ]
