import flask


myapp = flask.Flask("MyAPP")


#API-END POINT HERE
#http://127.0.0.1:5000/getlogdetails

@myapp.route("/getlogdetails")
def func_to_get_log_data():
            import sqlite3
            con = sqlite3.connect(r"C:\training\bin\my_database.sqlite3")
            cur = con.cursor()
            cur.execute("SELECT * FROM MY_WEBSITE_DATA")
            db_result = cur.fetchall()
            # db_result =[("123.123.123.123","abc.jpg"),("123.123.123.123","abc.jpg"),("123.123.123.123","abc.jpg")]

            # But in API, we need to send as json object
            # So, i need to make dictionary of
            db_result_dict = dict(enumerate(db_result))
            return flask.jsonify(db_result_dict)



myapp.run()
