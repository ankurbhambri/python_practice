import requests

my_api_endpoint = "http://127.0.0.1:5000/getlogdetails"

my_api_response = requests.get(my_api_endpoint)
my_api_response = my_api_response.json()
print("Data received from api : ")
print(my_api_response)
